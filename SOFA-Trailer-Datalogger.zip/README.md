# SOFA Trailer Datalogger

This project contains the source code to build and flash the SOFA Trailer Datalogger controllers.

## Hardware

ESP32-S3
CAN
Accelerometer

## Software

ESP-IDF v5.4.0 in VSCode, built from template-app sample project for project structure.
